<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\LandController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
 */

// public routes
route::get('/lands', [LandController::class, 'index']);
route::post('/lands/{id}', [LandController::class, 'show']);
route::post('/lands/search/{name}', [LandController::class, 'search']);
route::post('/register', [AuthController::class, 'register']);
route::post('/login', [AuthController::class, 'login']);

// protected routes
Route::group(['middleware' => ['auth:sanctum']], function () {
  route::post('/lands', [LandController::class, 'store']);
  route::put('/lands/{id}', [LandController::class, 'update']);
  route::delete('/lands/{id}', [LandController::class, 'destroy']);
  route::post('/logout', [AuthController::class, 'logout']);
});

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
  return $request->user();
});
