---
<?php echo $frontmatter; ?>

---

# Introduction

<?php echo $description; ?>


<?php echo $introText; ?>


<?php if($isInteractive): ?>
<script src="https://cdn.jsdelivr.net/npm/lodash@4.17.10/lodash.min.js"></script>
<script>
    var baseUrl = "<?php echo e($baseUrl); ?>";
</script>
<script src="js/tryitout-<?php echo e(\Knuckles\Scribe\Tools\Globals::SCRIBE_VERSION); ?>.js"></script>
<?php endif; ?>

> Base URL

```yaml
<?php echo $baseUrl; ?>

```<?php /**PATH /Users/umar/Desktop/rest-test/vendor/knuckleswtf/scribe/src/../resources/views//index.blade.php ENDPATH**/ ?>