# Authenticating requests

<?php if(!$isAuthed): ?>
This API is not authenticated.
<?php else: ?>
<?php echo $authDescription; ?>


<?php echo $extraAuthInfo; ?>

<?php endif; ?>
<?php /**PATH /Users/umar/Desktop/rest-test/vendor/knuckleswtf/scribe/src/../resources/views//authentication.blade.php ENDPATH**/ ?>